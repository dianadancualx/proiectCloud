#cheia pentru Google API
key = "AIzaSyCa1xJL-ZkOAjWQmRFVyUbTyq6XmTwJ9Co"